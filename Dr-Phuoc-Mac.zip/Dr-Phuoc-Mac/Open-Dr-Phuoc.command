#!/bin/bash
cd "$(dirname "$0")"
open "$(pwd)/Dr-Phuoc.html"
