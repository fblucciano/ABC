Dr. Phuoc — VenusP Planning Report (HTML)
==========================================

NO INSTALLATION. NO EXTRA SOFTWARE.

HOW TO OPEN
-----------
1. Unzip this folder
2. Double-click "Dr-Phuoc.html"
   OR double-click "Open-Dr-Phuoc.command"

3. Password: venus2026

4. Fill in the case → Export PDF

WORKS OFFLINE in Safari, Chrome, or any browser.

FILES
-----
Dr-Phuoc.html           The app (double-click this)
Open-Dr-Phuoc.command   Opens the app in your browser (Mac)

Keep both files in the same folder.
