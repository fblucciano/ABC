#!/bin/bash
cd "$(dirname "$0")"
chmod +x VenusP-Planning-mac_arm64 2>/dev/null
if [ -f "resources.neu" ] && [ -f "VenusP-Planning-mac_arm64" ]; then
    ./VenusP-Planning-mac_arm64
else
    osascript -e 'display alert "VenusP" message "Arquivos VenusP-Planning-mac_arm64 e resources.neu devem estar nesta pasta." as critical'
fi
