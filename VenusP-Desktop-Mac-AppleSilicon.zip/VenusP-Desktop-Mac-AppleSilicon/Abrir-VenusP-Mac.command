#!/bin/bash
cd "$(dirname "$0")"
chmod +x VenusP-Planning-mac_arm64 2>/dev/null
./VenusP-Planning-mac_arm64
